package com.example.tharu_000.cameras;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Date;

public class Cameras extends AppCompatActivity {
    EditText ava, work, nonwork, remark;
    Button sub,lo;
    Spinner toc;
    int a,w,n;
    String sava,sw,snw,sr,sc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cameras);
        ava = (EditText) findViewById(R.id.available);
        work = (EditText) findViewById(R.id.work);
        nonwork = (EditText) findViewById(R.id.non_work);
        remark = (EditText) findViewById(R.id.remarks);
        toc = (Spinner)findViewById(R.id.tocam);
        sub = (Button)findViewById(R.id.submit);
        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Cameras.this,MainActivity.class));
                finish();
            }
        });
        String[] items=new String[]{"Select cam","PTZ Cameras","Fixed Cameras"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,items);
        toc.setAdapter(adapter);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sava = ava.getText().toString();
                sw = work.getText().toString();
                snw = nonwork.getText().toString();
                sr = remark.getText().toString();
                sc = toc.getSelectedItem().toString();
                a = Integer.parseInt(sava);
                w = Integer.parseInt(sw);
                n = Integer.parseInt(snw);
                if(a==(w+n)) {
                    new Background(Cameras.this).execute("cam", sava, sw, snw, sr, sc);
                }else {
                    Toast.makeText(Cameras.this,"Enter Correct Details",Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}