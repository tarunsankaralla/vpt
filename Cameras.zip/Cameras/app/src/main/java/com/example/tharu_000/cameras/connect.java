package com.example.tharu_000.cameras;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.tharu_000.cameras.Login.ldes;

public class connect extends AppCompatActivity {

    Button cam,other,lo;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);
        cam = (Button)findViewById(R.id.cam);
        other = (Button)findViewById(R.id.other);
        cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ldes.contains("AE")){
                    startActivity(new Intent(connect.this,Cameras.class));
                }else if(ldes.contains("SE")){
                    startActivity(new Intent(connect.this,Verify.class));
                }
            }
        });
        other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ldes.contains("AE")){
                    startActivity(new Intent(connect.this,Others.class));
                }else if (ldes.contains("SE")){
                    startActivity(new Intent(connect.this,Verify1.class));
                }
            }
        });

        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(connect.this,MainActivity.class));
                finish();
            }
        });
    }
}
