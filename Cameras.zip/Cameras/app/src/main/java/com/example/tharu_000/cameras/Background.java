package com.example.tharu_000.cameras;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by tharu_000 on 17-06-2017.
 */

public class Background extends AsyncTask<String,Void,String> {
    Context context;
    String type,id,password,desg;
    Background(Context ctx){context = ctx;}
    @Override
    protected String doInBackground(String... strings) {
        String res = null;
        String login_url="https://bollinenianju.000webhostapp.com/plogin.php";
        String cam_url = "https://bollinenianju.000webhostapp.com/pcam.php";
        String other_url = "https://bollinenianju.000webhostapp.com/pbridge.php";
        String cav_url ="https://bollinenianju.000webhostapp.com/cam2.php";
        String rv_url= "https://bollinenianju.000webhostapp.com/bridge2.php";
        type = strings[0];
        if(type.contains("login")){
            try {
                id = strings[1];
                password = strings[2];
                desg = strings[3];
                URL url = new URL(login_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8") + "&"
                        + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8")+ "&"
                        + URLEncoder.encode("desg", "UTF-8") + "=" + URLEncoder.encode(desg, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));

                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }

                istream.close();
                br.close();
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
        }
        if(type.contains("cam")){
            try {
                String ava = strings[1];
                String work = strings[2];
                String nonwork = strings[3];
                String rem = strings[4];
                String tc = strings[5];
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

// Get the date today using Calendar object.
                Date today = Calendar.getInstance().getTime();
// Using DateFormat format method we can create a string
// representation of a date with the defined format.
                String reportDate = df.format(today);
                URL url = new URL(cam_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("avail", "UTF-8") + "=" + URLEncoder.encode(ava, "UTF-8") + "&"
                        + URLEncoder.encode("work", "UTF-8") + "=" + URLEncoder.encode(work, "UTF-8")+ "&"
                        + URLEncoder.encode("nonwork", "UTF-8") + "=" + URLEncoder.encode(nonwork, "UTF-8")+ "&"
                        + URLEncoder.encode("rem", "UTF-8") + "=" + URLEncoder.encode(rem, "UTF-8")+ "&"
                        + URLEncoder.encode("tc", "UTF-8") + "=" + URLEncoder.encode(tc, "UTF-8")+ "&"
                        + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(reportDate, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));

                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }

                istream.close();
                br.close();
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
        }
        if(type.contains("other")){
            try {
                String rtww = strings[1];
                String rtwnw = strings[2];
                String rnaw = strings[3];
                String rnanw = strings[4];
                String rdew = strings[5];
                String rdenw = strings[6];
                String rfidw = strings[7];
                String rfidnw = strings[8];
                String rem = strings[9];
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

// Get the date today using Calendar object.
                Date today = Calendar.getInstance().getTime();
// Using DateFormat format method we can create a string
// representation of a date with the defined format.
                String reportDate = df.format(today);
                URL url = new URL(other_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("rtww", "UTF-8") + "=" + URLEncoder.encode(rtww, "UTF-8") + "&"
                        + URLEncoder.encode("rtwnw", "UTF-8") + "=" + URLEncoder.encode(rtwnw, "UTF-8")+ "&"
                        + URLEncoder.encode("rnaw", "UTF-8") + "=" + URLEncoder.encode(rnaw, "UTF-8")+ "&"
                        + URLEncoder.encode("rnanw", "UTF-8") + "=" + URLEncoder.encode(rnanw, "UTF-8")+ "&"
                        + URLEncoder.encode("rdew", "UTF-8") + "=" + URLEncoder.encode(rdew, "UTF-8")+ "&"
                        + URLEncoder.encode("rdenw", "UTF-8") + "=" + URLEncoder.encode(rdenw, "UTF-8")+ "&"
                        + URLEncoder.encode("rfidw", "UTF-8") + "=" + URLEncoder.encode(rfidw, "UTF-8")+ "&"
                        + URLEncoder.encode("rfidnw", "UTF-8") + "=" + URLEncoder.encode(rfidnw, "UTF-8")+ "&"
                        + URLEncoder.encode("rem", "UTF-8") + "=" + URLEncoder.encode(rem, "UTF-8")+ "&"
                        + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(reportDate, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));
                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }

                istream.close();
                br.close();
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
        }
        if(type.contains("camsv")){
            try {
                String status = strings[1];
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

// Get the date today using Calendar object.
                Date today = Calendar.getInstance().getTime();
// Using DateFormat format method we can create a string
// representation of a date with the defined format.
                String reportDate = df.format(today);
                URL url = new URL(cav_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("status", "UTF-8") + "=" + URLEncoder.encode(status, "UTF-8")+ "&"
                        + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(reportDate, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));
                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }

                istream.close();
                br.close();
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
        }
        if(type.contains("rv")){
            try {
                String status = strings[1];
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

// Get the date today using Calendar object.
                Date today = Calendar.getInstance().getTime();
// Using DateFormat format method we can create a string
// representation of a date with the defined format.
                String reportDate = df.format(today);
                URL url = new URL(rv_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("status", "UTF-8") + "=" + URLEncoder.encode(status, "UTF-8")+ "&"
                        + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(reportDate, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));
                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }

                istream.close();
                br.close();
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
        }

        return res;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
        if(type.contains("login") && s.contains("Login")){
           if(desg.contains("AE")){context.startActivity(new Intent(context,connect.class));}
            else if(desg.contains("SE")){context.startActivity(new Intent(context,higdes.class));}
        }
    }
}