package com.example.tharu_000.cameras;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.example.tharu_000.cameras.Login.ldes;

public class Verify1 extends AppCompatActivity {
    TextView rtww,rtwm,rdew,rden,rnaw,rnan,rfidw,rfidn,rem;
    String srtww,srtwm,srdew,srden,srnaw,srnan,srfidw,srfidn,srem,status;
    Button lo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify1);
        new show1().execute(ldes);
        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Verify1.this,MainActivity.class));
                finish();
            }
        });



    }
    private class show1 extends AsyncTask<String,Void,String> {
        String res;
        String show_url = "https://bollinenianju.000webhostapp.com/bridge1.php";
        @Override
        protected String doInBackground(String... strings) {
            try {
                String ldes1 = strings[0];
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

// Get the date today using Calendar object.
                Date today = Calendar.getInstance().getTime();
// Using DateFormat format method we can create a string
// representation of a date with the defined format.
                String reportDate = df.format(today);
                URL url = new URL(show_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("status", "UTF-8") + "=" + URLEncoder.encode(ldes1, "UTF-8")+ "&"
                        + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(reportDate, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));
                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }
                istream.close();
                br.close();
                conn.disconnect();
                JSONObject jsonObj = new JSONObject(res);
                srtww = jsonObj.getString("rtww");
                srtwm = jsonObj.getString("rtwn");
                srnaw = jsonObj.getString("rnaw");
                srnan = jsonObj.getString("rnan");
                srdew = jsonObj.getString("rdew");
                srden = jsonObj.getString("rden");
                srfidw = jsonObj.getString("rfidw");
                srfidn = jsonObj.getString("rfidn");
                srem = jsonObj.getString("rem");
            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
            return res;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
         //   Toast.makeText(Verify1.this, s ,Toast.LENGTH_LONG).show();

          if(srtww.equals("null") && srden.equals("null")){
                startActivity(new Intent(Verify1.this,higdes.class));
                Toast.makeText(Verify1.this,"No new requests",Toast.LENGTH_LONG).show();
            }
            rtww = (TextView)findViewById(R.id.vrtww);
            rtwm = (TextView)findViewById(R.id.vrtwn);
            rdew = (TextView)findViewById(R.id.vrdew);
            rden = (TextView)findViewById(R.id.vrden);
            rnaw = (TextView)findViewById(R.id.vrnaw);
            rnan = (TextView)findViewById(R.id.vrnan);
            rfidw = (TextView)findViewById(R.id.vrfidw);
            rfidn = (TextView)findViewById(R.id.vrfidn);
            rem = (TextView)findViewById(R.id.v2rem);
            rtww.setText("Working:      "+srtww);
            rtwm.setText("Non-Working:  "+srtwm);
            rdew.setText("Working:      "+srdew);
            rden.setText("Non-Working:  "+srden);
            rnaw.setText("Working:      "+srnaw);
            rnan.setText("Non-Working:  "+srnan);
            rfidw.setText("Working:      "+srfidw);
            rfidn.setText("Non-Working:  "+srfidn);
            rem.setText("Remarks:      "+srem);
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

}
