package com.example.tharu_000.cameras;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Others extends AppCompatActivity {
    EditText rtww,rtwnw,rnaw,rnanw,rdew,rdenw,rfidw,rfidnw,rem;
    Button sub,lo;
    String srtw,srtnw,srnw,srnnw,srdw,srdnw,srfw,srfnw,srem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_others);
        sub = (Button)findViewById(R.id.sub);
        rtww = (EditText)findViewById(R.id.rtwwork);
        rtwnw = (EditText)findViewById(R.id.rtwnwork);
        rnaw = (EditText)findViewById(R.id.rnanwork);
        rnanw = (EditText)findViewById(R.id.rnanwork);
        rdew = (EditText)findViewById(R.id.rdework);
        rdenw = (EditText)findViewById(R.id.rdenwork);
        rfidw = (EditText)findViewById(R.id.rfidwork);
        rfidnw = (EditText)findViewById(R.id.rfidnwork);
        rem = (EditText)findViewById(R.id.oremarks);
        sub = (Button)findViewById(R.id.sub);
        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Others.this,MainActivity.class));
                finish();
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                srtw = rtww.getText().toString();
                srtnw = rtwnw.getText().toString();
                srnw = rnaw.getText().toString();
                srnnw = rnanw.getText().toString();
                srdw = rdew.getText().toString();
                srdnw = rdenw.getText().toString();
                srfw = rfidw.getText().toString();
                srfnw = rfidnw.getText().toString();
                srem = rem.getText().toString();
                new Background(Others.this).execute("other",srtw,srtnw,srnw,srnnw,srdw,srdnw,srfw,srfnw,srem);
            }
        });
    }
}
