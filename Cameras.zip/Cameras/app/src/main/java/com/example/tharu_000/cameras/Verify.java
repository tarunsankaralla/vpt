package com.example.tharu_000.cameras;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.example.tharu_000.cameras.Login.ldes;

public class Verify extends AppCompatActivity {
    TextView c1,c2,a1,a2,w1,w2,n1,n2,r1,r2;
    String sc1,sc2,sa1,sa2,sw1,sw2,sn1,sn2,sr1,sr2,status;
    Button frw1,lo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);
        new show1().execute(ldes);
        frw1 = (Button)findViewById(R.id.frw);
        frw1.setVisibility(View.GONE);
        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Verify.this,MainActivity.class));
                finish();
            }
        });
    /*    frw1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ldes.contains("aecam")){
                    status = "secam";
                    new Background(Verify.this).execute("camsv",status);
                }else if (ldes.contains("secam")){status="hodcam";
                    new Background(Verify.this).execute("camsv",status);}
            }
        });*/
    }
    private class show1 extends AsyncTask<String,Void,String> {
        String res;
        String show_url = "https://bollinenianju.000webhostapp.com/cam1.php";
        @Override
        protected String doInBackground(String... strings) {
            try {
                String ldes1 = strings[0];
                DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
// Get the date today using Calendar object.
                Date today = Calendar.getInstance().getTime();
// Using DateFormat format method we can create a string
// representation of a date with the defined format.
                String reportDate = df.format(today);
                URL url = new URL(show_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.connect();
                OutputStream ostream = conn.getOutputStream();
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                String data = URLEncoder.encode("status", "UTF-8") + "=" + URLEncoder.encode(ldes1, "UTF-8")+ "&"
                        + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(reportDate, "UTF-8");
                bw.write(data);
                bw.flush();
                bw.close();
                ostream.close();
                InputStream istream = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));
                res = "";
                String line;
                while ((line = br.readLine()) != null) {
                    res += line;
                }
                istream.close();
                br.close();
                conn.disconnect();
                JSONObject jsonObj = new JSONObject(res);
                sc1 = jsonObj.getString("c1");
                sa1 = jsonObj.getString("a1");
                sw1 = jsonObj.getString("w1");
                sn1 = jsonObj.getString("n1");
                sr1 = jsonObj.getString("r1");
                sc2 = jsonObj.getString("c2");
                sa2 = jsonObj.getString("a2");
                sw2 = jsonObj.getString("w2");
                sn2 = jsonObj.getString("n2");
                sr2 = jsonObj.getString("r2");
            } catch (Exception e) {
                e.printStackTrace();
                res = e.getMessage();
            }
            return res;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           Toast.makeText(Verify.this, s ,Toast.LENGTH_LONG).show();
         /*   if(sc1.equals("null") && sc2.equals("null")){
                startActivity(new Intent(Verify.this,higdes.class));
                Toast.makeText(Verify.this,"No new requests",Toast.LENGTH_LONG).show();
            }*/
            c1 = (TextView)findViewById(R.id.vc1);
            a1 = (TextView)findViewById(R.id.va1);
            w1 = (TextView)findViewById(R.id.vw1);
            n1 = (TextView)findViewById(R.id.vn1);
            r1 = (TextView)findViewById(R.id.vr1);
            c2 = (TextView)findViewById(R.id.vc2);
            a2 = (TextView)findViewById(R.id.va2);
            w2 = (TextView)findViewById(R.id.vw2);
            n2 = (TextView)findViewById(R.id.vn2);
            r2 = (TextView)findViewById(R.id.vr2);
            c1.setText("Camera Type:  "+sc1);
            c2.setText("Camera Type:  "+sc2);
            a1.setText("Available:    "+sa1);
            a2.setText("Available:    "+sa2);
            w1.setText("Working:      "+sw1);
            w2.setText("Working:      "+sw2);
            n1.setText("Non-Working:  "+sn1);
            n2.setText("Non-Working:  "+sn2);
            r1.setText("Remarks:      "+sr1);
            r2.setText("Remarks:      "+sr2);
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

}
