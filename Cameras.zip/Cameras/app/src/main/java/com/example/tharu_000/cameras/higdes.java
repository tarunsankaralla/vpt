package com.example.tharu_000.cameras;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.tharu_000.cameras.Login.ldes;

public class higdes extends AppCompatActivity {
    Button qur,ver,lo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_higdes);
        qur = (Button)findViewById(R.id.query);
        ver = (Button)findViewById(R.id.verify);
        qur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(higdes.this,Chat.class));
            }
        });
        ver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(higdes.this,connect.class));}
        });
        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(higdes.this,MainActivity.class));
                finish();
            }
        });
    }
}
