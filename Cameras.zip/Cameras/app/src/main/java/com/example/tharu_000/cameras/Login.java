package com.example.tharu_000.cameras;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Login extends AppCompatActivity {
    EditText id,pass;
    Spinner des;
    public static String lid,lpass,ldes;
    Button login1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        id = (EditText) findViewById(R.id.id);
        pass = (EditText)findViewById(R.id.pass);
        des = (Spinner)findViewById(R.id.desg);
        String[] items=new String[]{"Select Designation","AE","SE"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,items);
        des.setAdapter(adapter);
        login1 = (Button)findViewById(R.id.log);
        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lid = id.getText().toString();
                lpass = pass.getText().toString();
                ldes = des.getSelectedItem().toString();
                new Background(Login.this).execute("login",lid,lpass,ldes);
            }
        });
    }
}
