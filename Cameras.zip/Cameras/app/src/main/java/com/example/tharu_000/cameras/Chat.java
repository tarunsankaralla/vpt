package com.example.tharu_000.cameras;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import static com.example.tharu_000.cameras.Login.ldes;
import static com.example.tharu_000.cameras.Login.lid;

public class Chat extends AppCompatActivity {

    EditText qu;
    Button sub,lo;
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        qu = (EditText)findViewById(R.id.comment);
        sub = (Button)findViewById(R.id.send);
        lo = (Button)findViewById(R.id.logout);
        lo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Chat.this,MainActivity.class));
                finish();
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = qu.getText().toString();
                if(ldes.contains("SE")){
                      new msg().execute("msg",lid,ldes,"AE",s);
                }
            }
        });
    }
    private class msg extends AsyncTask<String,Void,String> {
        String res,type,id,fdes,tdes,messa;
        @Override
        protected String doInBackground(String... strings) {
            String other_url = "https://bollinenianju.000webhostapp.com/msg.php";
            type = strings[0];
            if(type.contains("msg")){
                try {
                    id = strings[1];
                    fdes = strings[2];
                    tdes = strings[3];
                    messa = strings[4];
                    URL url = new URL(other_url);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setDoInput(true);
                    conn.connect();
                    OutputStream ostream = conn.getOutputStream();
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(ostream, "UTF-8"));
                    String data = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8") + "&"
                            + URLEncoder.encode("fdes", "UTF-8") + "=" + URLEncoder.encode(fdes, "UTF-8")+ "&"
                            + URLEncoder.encode("tdes", "UTF-8") + "=" + URLEncoder.encode(tdes, "UTF-8")+ "&"
                            + URLEncoder.encode("msg", "UTF-8") + "=" + URLEncoder.encode(messa, "UTF-8");
                    bw.write(data);
                    bw.flush();
                    bw.close();
                    ostream.close();
                    InputStream istream = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(istream, "UTF-8"));

                    res = "";
                    String line;
                    while ((line = br.readLine()) != null) {
                        res += line;
                    }

                    istream.close();
                    br.close();
                    conn.disconnect();

                } catch (Exception e) {
                    e.printStackTrace();
                    res = e.getMessage();
                }
            }

            return res;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(Chat.this,s,Toast.LENGTH_SHORT).show();
            if(s.contains("success")){
              qu.setText("");
            }
        }
    }

}
